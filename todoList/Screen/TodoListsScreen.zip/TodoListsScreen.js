import React, { useEffect, useState, useContext } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { UsernameContext, TokenContext } from '../Context/Context';

// URL de l'API GraphQL
const API_URL = 'http://graphql.unicaen.fr:4000';

// Requête GraphQL pour récupérer les TodoLists
const GET_TODOLISTS_QUERY = `
query TodoLists($where: TodoListWhere) {
  todoLists(where: $where) {
    id
    title
    owner {
      username
    }
  }
}
`;

// Requête GraphQL pour récupérer les Todos d'une TodoList
const GET_TODOS_FOR_TODOLIST_QUERY = `
query Todos($where: TodoWhere) {
  todos(where: $where) {
    id
    content
    done
    belongsTo {
      title
    }
  }
}
`;

export default function TodoListsScreen() {
  const [todoLists, setTodoLists] = useState([]);   
  const [errorMessage, setErrorMessage] = useState(''); 

  const [username] = useContext(UsernameContext);  
  const [token] = useContext(TokenContext);         

  const fetchTodoLists = async () => {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          query: GET_TODOLISTS_QUERY,
          variables: {
            where: {
              owner: {
                username: username,
              },
            },
          },
        }),
      });
      
      const jsonResponse = await response.json();
      if (jsonResponse.errors) {
        throw new Error(jsonResponse.errors[0].message);
      }

      setTodoLists(jsonResponse.data.todoLists);
    } catch (error) {
      setErrorMessage(error.message);
    }
  };

  const fetchTodosForTodoList = async (todoListId) => {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          query: GET_TODOS_FOR_TODOLIST_QUERY,
          variables: {
            where: {
              belongsTo: {
                id: todoListId,  // Utiliser l'ID de la TodoList pour récupérer les todos
              },
            },
          },
        }),
      });

      const jsonResponse = await response.json();
      if (jsonResponse.errors) {
        throw new Error(jsonResponse.errors[0].message);
      }

      // Retourner les todos récupérés
      return jsonResponse.data.todos;
    } catch (error) {
      console.error(error);
      return [];
    }
  };

  useEffect(() => {
    if (username) {
      fetchTodoLists();
    }
  }, [username]);

  // Utiliser useEffect pour récupérer les todos après que les TodoLists aient été chargées
  useEffect(() => {
    const loadTodosForTodoLists = async () => {
      const updatedTodoLists = await Promise.all(
        todoLists.map(async (todoList) => {
          const todos = await fetchTodosForTodoList(todoList.id);
          return { ...todoList, todos }; // Ajouter les todos à la TodoList
        })
      );
      setTodoLists(updatedTodoLists);
    };

    if (todoLists.length > 0) {
      loadTodosForTodoLists();
    }
  }, [todoLists]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Todo Lists</Text>
      {errorMessage ? <Text style={styles.error}>{errorMessage}</Text> : null}
      
      <FlatList
        data={todoLists}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.todoItem}>
            <Text style={styles.listTitle}>{item.title}</Text>
            <FlatList
              data={item.todos} // Afficher les todos associés
              keyExtractor={(todo) => todo.id.toString()}
              renderItem={({ item: todo }) => (
                <View style={styles.todoSubItem}>
                  <Text>{todo.content} </Text>
                </View>
              )}
            />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
  },
  todoItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderColor: '#ccc',
    marginBottom: 12,
  },
  todoSubItem: {
    paddingLeft: 20, // Indentation pour les todos
    paddingVertical: 4,
  },
  error: {
    color: 'red',
    marginBottom: 12,
  },
});

/*import React from 'react';
import { View, StyleSheet } from 'react-native';
import TodoList from '../components/TodoList'; 

export default function TodoListsScreen() {
  return (
    <View style={styles.container}>
      <TodoList />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
});
/*
query TodoLists($where: TodoListWhere) {
  todoLists(where: $where) {
    id
    title
  }
}*/
/*
{
  "where": {
    "owner": {
      "username": "kiki"
    }
  }
}*/
/*
mutation CreateTodos($input: [TodoCreateInput!]!) {
  createTodos(input: $input) {
    todos {
      id
      content
      done
      belongsTo {
        title
      }
    }
  }
}*/
/** {
  "input": [
    {
      "content": "je suis le todo 1",
      "done": true,
      "belongsTo": {
        "connect": {
          "where": {
            "title": "todoList1"
          }
        }
      }
    }
  ]
}*/