import React, { useState, useContext } from 'react'; 
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity } from 'react-native';
import { TokenContext, UsernameContext } from '../Context/Context'; // Importation des contextes

// URL de l'API GraphQL
const API_URL = 'http://graphql.unicaen.fr:4000';

// La mutation GraphQL pour SignIn
const SIGN_IN_MUTATION = `
mutation SignIn($username: String!, $password: String!) {
  signIn(username: $username, password: $password)
}
`;

export default function SignInScreen({ navigation }) {
  const [, setUsername] = useContext(UsernameContext);
  const [, setToken] = useContext(TokenContext);

  const [inputUsername, setInputUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSignIn = async () => {
    try {
      const token = await signIn(inputUsername, password);
      setUsername(inputUsername);
      setToken(token);
      navigation.navigate('Home');
    } catch (error) {
      setErrorMessage(error.message);
    }
  };

  const signIn = (username, password) => {
    return fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query: SIGN_IN_MUTATION,
        variables: { username, password }
      })
    })
    .then(response => response.json())
    .then(jsonResponse => {
      if (jsonResponse.errors) {
        throw new Error(jsonResponse.errors[0].message);
      }
      return jsonResponse.data.signIn;
    })
    .catch(error => {
      throw error;
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sign In</Text>
      <TextInput
        style={styles.input}
        placeholder='Username'
        value={inputUsername}
        onChangeText={setInputUsername}
      />
      <TextInput
        style={styles.input}
        placeholder='Password'
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      {errorMessage ? <Text style={styles.error}>{errorMessage}</Text> : null}
      <Button title='Sign In' onPress={handleSignIn} />

      {/* Bouton pour aller à l'écran Sign Up */}
      <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
        <Text style={styles.signUpText}>
          Don't have an account? Sign Up
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles pour le composant
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 24,
  },
  input: {
    height: 40,
    width: '100%',
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  error: {
    color: 'red',
    marginBottom: 12,
  },
  signUpText: {
    marginTop: 20,
    color: 'blue',
    textDecorationLine: 'underline',
  },
});
